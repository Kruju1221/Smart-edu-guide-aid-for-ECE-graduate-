package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ViewNotif extends Activity {

    ViewNotifAdapter adapter;
    ListView lstView;
    ArrayList<HashMap<String, String>> arraylist;

    String sem;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_notif_student);

        Intent i = getIntent();
        sem = i.getStringExtra("Sem");

//        Toast.makeText(getApplicationContext(), "Selected Semester: "+sem, Toast.LENGTH_LONG).show();

        lstView = (ListView) findViewById(R.id.notifListView);
        getProperties();
    }

    private void getProperties() {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = Config.getNotif+"?sem="+sem;

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        arraylist = new ArrayList<HashMap<String, String>>();
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                HashMap<String, String> map = new HashMap<String, String>();
                                map.put("id", jsonObject.getString("id"));
                                map.put("title", jsonObject.getString("title"));
                                map.put("message", jsonObject.getString("message"));
                                map.put("created_at", jsonObject.getString("created_at"));

                                arraylist.add(map);
                            }
                            adapter = new ViewNotifAdapter(ViewNotif.this, arraylist);
                            lstView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

        queue.add(jsonArrayRequest);
    }
}