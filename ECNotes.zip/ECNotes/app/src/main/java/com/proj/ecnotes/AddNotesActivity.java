package com.proj.ecnotes;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AddNotesActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SELECT_FILE = 1;
    private static final MediaType MEDIA_TYPE_OCTET_STREAM = MediaType.parse("application/octet-stream");
    private static final String TAG = "AddNotesActivity";

    private Button uploadButton, selectFileButton;
    private TextView selectedFileTextView;

    private Spinner subjectSpinner, unitsSpinner, semesterSpinner;

    private EditText etYoutubelinks;

    private Uri selectedFileUri;
    private static final String UPLOAD_NOTE_URL = Config.addNotes; // replace with your backend endpoint
    private static final String LOAD_SEMESTER_URL = Config.getSemesters;
    private static final String LOAD_SUBJECTS_URL = Config.getSubjects;
    private static final String LOAD_UNITS_URL = Config.getUnits;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_notes);

        uploadButton = findViewById(R.id.uploadButton);
        selectFileButton = findViewById(R.id.selectFileButton);
        selectedFileTextView = findViewById(R.id.selectedFileTextView);

        subjectSpinner = findViewById(R.id.subjectSpinner);
        unitsSpinner = findViewById(R.id.unitsSpinner);
        semesterSpinner = findViewById(R.id.semesterSpinner);
        etYoutubelinks = findViewById(R.id.etYoutubelinks);



        selectFileButton.setOnClickListener(v -> selectFile());
        uploadButton.setOnClickListener(v -> uploadNote());

        loadSemesterData();
        loadUnitsData();

        // Assuming you have already initialized subjectSpinner, unitsSpinner, and semesterSpinner

        semesterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedSemester = parentView.getItemAtPosition(position).toString();
                loadSubjectsData(selectedSemester);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing if nothing is selected
            }
        });

        subjectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedSubject = parentView.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing if nothing is selected
            }
        });

    }

    private void loadSemesterData() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_SEMESTER_URL) // replace with your backend endpoint
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(AddNotesActivity.this, "Failed to load semester data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load semester data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetSemesterData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(AddNotesActivity.this, "Failed to load semester data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load semester data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetSemesterData(String jsonData) {
        try {
            Log.d(TAG, "Semester JSON Data: " + jsonData);
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> semesters = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                semesters.add(jsonObject.getString("semester"));
            }

            ArrayAdapter<String> semesterAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, semesters);
            semesterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            semesterSpinner.setAdapter(semesterAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing semester data: ", e);
            Toast.makeText(this, "Error parsing semester data", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadSubjectsData(String selectedSemester) {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_SUBJECTS_URL + "?semester=" + selectedSemester) // URL to load subjects data based on selected semester
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(AddNotesActivity.this, "Failed to load subjects data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load subjects data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetSubjectsData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(AddNotesActivity.this, "Failed to load subjects data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load subjects data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetSubjectsData(String jsonData) {
        try {
            Log.d(TAG, "Subjects JSON Data: " + jsonData);
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> subjects = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                subjects.add(jsonObject.getString("subject"));
            }

            ArrayAdapter<String> subjectAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, subjects);
            subjectAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            subjectSpinner.setAdapter(subjectAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing subject data: ", e);
            Toast.makeText(this, "Error parsing subject data", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadUnitsData() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_UNITS_URL) // URL to load units data based on selected subject
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(AddNotesActivity.this, "Failed to load units data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load units data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetUnitsData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(AddNotesActivity.this, "Failed to load units data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load units data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetUnitsData(String jsonData) {
        try {
            Log.d(TAG, "Units JSON Data: " + jsonData);
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> units = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                units.add(jsonObject.getString("unitname"));
            }

            ArrayAdapter<String> unitsAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, units);
            unitsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            unitsSpinner.setAdapter(unitsAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing units data: ", e);
            Toast.makeText(this, "Error parsing units data", Toast.LENGTH_SHORT).show();
        }
    }

    public void selectFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, REQUEST_CODE_SELECT_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SELECT_FILE && resultCode == RESULT_OK) {
            selectedFileUri = data.getData();
            if (selectedFileUri != null) {
                selectedFileTextView.setText(getFileName(selectedFileUri));
            }
        }
    }

    private String getFileName(Uri uri) {
        String path = uri.getPath();
        if (path != null) {
            int lastIndex = path.lastIndexOf('/');
            return (lastIndex != -1) ? path.substring(lastIndex + 1) : "unknown_file";
        }
        return "unknown_file";
    }

    private void uploadNote() {
        final String semester = semesterSpinner.getSelectedItem().toString().trim();
        final String subject = subjectSpinner.getSelectedItem().toString().trim();
        final String unit = unitsSpinner.getSelectedItem().toString().trim();
        final String youtubelinks = etYoutubelinks.getText().toString();

        if (semester.isEmpty()) {
            Toast.makeText(this, "Please select semester", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedFileUri == null) {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            try {
                // Create a temporary file to upload
                File tempFile = new File(getCacheDir(), getFileName(selectedFileUri));
                try (InputStream inputStream = getContentResolver().openInputStream(selectedFileUri);
                     FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, len);
                    }
                }

                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(15, TimeUnit.SECONDS)
                        .writeTimeout(15, TimeUnit.SECONDS)
                        .readTimeout(15, TimeUnit.SECONDS)
                        .build();

                MultipartBody.Builder multipartBuilder = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("semester", semester)
                        .addFormDataPart("subject", subject)
                        .addFormDataPart("unit", unit)
                        .addFormDataPart("youtubelinks", youtubelinks)
                        .addFormDataPart("file", tempFile.getName(),
                                RequestBody.create(MEDIA_TYPE_OCTET_STREAM, tempFile));

                Request request = new Request.Builder()
                        .url(UPLOAD_NOTE_URL) // replace with your backend endpoint
                        .post(multipartBuilder.build())
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(this, "Upload Successful", Toast.LENGTH_SHORT).show());
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Upload Failed", Toast.LENGTH_SHORT).show());
                }

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}

