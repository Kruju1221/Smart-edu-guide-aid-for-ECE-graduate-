package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class SelectSemesterNotif extends Activity {

    private Spinner semesterSpinner;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_semester_notif);

        semesterSpinner = findViewById(R.id.semesterSpinner);
        nextButton = findViewById(R.id.nextButton);

        // Set up the spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.semester_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        semesterSpinner.setAdapter(adapter);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedPosition = semesterSpinner.getSelectedItemPosition();
                if (selectedPosition != AdapterView.INVALID_POSITION) {
                    String selectedSemester = semesterSpinner.getSelectedItem().toString();
                    Intent intent = new Intent(SelectSemesterNotif.this, ViewNotif.class);
                    intent.putExtra("Sem", selectedSemester);
                    startActivity(intent);
                } else {
                    Toast.makeText(SelectSemesterNotif.this, "Please select a semester", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
