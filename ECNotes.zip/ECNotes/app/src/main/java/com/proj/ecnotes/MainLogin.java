package com.proj.ecnotes;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainLogin extends Activity {

    private Button studentLoginButton;
    private Button facultyLoginButton;
    private Button adminLoginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_login);

        // Initialize buttons
        studentLoginButton = findViewById(R.id.studentLoginButton);
        facultyLoginButton = findViewById(R.id.facultyLoginButton);
        adminLoginButton = findViewById(R.id.adminLoginButton);


        // Set onClickListener for Student Login button
        adminLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start StudentLogin activity
                String url = "http://"+Config.ipAddress+"/ECNotesWeb/admin.php";
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

        studentLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start StudentLogin activity
                Intent intent = new Intent(MainLogin.this, LoginStudentActivity.class);
                startActivity(intent);
            }
        });

        // Set onClickListener for Faculty Login button
        facultyLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start FacultyLogin activity
                Intent intent = new Intent(MainLogin.this, FacultyLogin.class);
                startActivity(intent);
            }
        });
        // Set onClickListener for Admin Login button
    }
}