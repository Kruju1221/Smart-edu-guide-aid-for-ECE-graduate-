package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class SelectYearEvent extends Activity {

    private Spinner yearSpinner;
    private Button nextButton;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_year_event);

        yearSpinner = findViewById(R.id.yearSpinner);
        nextButton = findViewById(R.id.nextButton);

        setupYearSpinner();
        setupNextButton();
    }

    private void setupYearSpinner() {
        List<String> years = new ArrayList<>();
        for (int i = 1900; i <= 2100; i++) {
            years.add(String.valueOf(i));
        }

        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, years);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSpinner.setAdapter(yearAdapter);
    }

    private void setupNextButton() {
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedYear = yearSpinner.getSelectedItem().toString();
                Intent intent = new Intent(SelectYearEvent.this, ViewEvents.class);
                intent.putExtra("selectedYear", selectedYear);
                startActivity(intent);
            }
        });
    }
}
