package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class SemesterBoard extends Activity {

    private Spinner semesterSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.semboard);

        semesterSpinner = findViewById(R.id.semesterSpinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.semester_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        semesterSpinner.setAdapter(adapter);

        semesterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (position == 0) {
                    Toast.makeText(getApplicationContext(), "Select Your option" + String.valueOf(position), Toast.LENGTH_LONG).show();
                } else {
                    String selectedSemester = parent.getItemAtPosition(position).toString();
                    Toast.makeText(getApplicationContext(), "Selected: " + selectedSemester, Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(SemesterBoard.this, StudentDashboard.class);
                    intent.putExtra("Sem", String.valueOf(position));
                    startActivity(intent);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }
}
