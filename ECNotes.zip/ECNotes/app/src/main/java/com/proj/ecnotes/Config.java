package com.proj.ecnotes;

public class Config {

    public static String ipAddress = "192.168.43.253";

    /* Notes... */
    public static String addNotes = "http://"+ipAddress+"/ECNotesWeb/addNotes.php";
    public static String getSemesters  = "http://"+ipAddress+"/ECNotesWeb/getSemesters.php";
    public static String getSubjects  = "http://"+ipAddress+"/ECNotesWeb/getSubjects.php";
    public static String getUnits  = "http://"+ipAddress+"/ECNotesWeb/getUnits.php";

    public static String getNotes = "http://"+ipAddress+"/ECNotesWeb/getAllNotes.php";

    /* Syllabus... */
    public static String getRanges  = "http://"+ipAddress+"/ECNotesWeb/getRanges.php";
    public static String addSyllabus = "http://"+ipAddress+"/ECNotesWeb/addSyllabus.php";

    /* Projects... */
    public static String addProjects = "http://"+ipAddress+"/ECNotesWeb/addProjects.php";

    /* Notifications... */
    public static String getNotif = "http://"+ipAddress+"/ECNotesWeb/getNotif.php";



    public static String addStudent = "http://"+ipAddress+"/ECNotesWeb/addstudent.php";
    public static String registerFaculty = "http://"+ipAddress+"/ECNotesWeb/registerfaculty.php";
    public static String login =  "http://"+ipAddress+"/ECNotesWeb/login.php";
    public static String getNotes2 = "http://"+ipAddress+"/ECNotesWeb/getNotes.php";
    public static String loginStudent = "http://"+ipAddress+"/ECNotesWeb/loginstudent.php";
    public static String loginAdmin = "http://"+ipAddress+"/ECNotesWeb/loginAdmin.php";
    public static String facultyLogin = "http://"+ipAddress+"/ECNotesWeb/loginfaculty.php";
    public static String regAll = "http://"+ipAddress+"/ECNotesWeb/regAll.php";

    public static String getSyllabus = "http://"+ipAddress+"/ECNotesWeb/getSyllabus.php";
    public static String getProjects = "http://"+ipAddress+"/ECNotesWeb/getProjects.php";
    public static String getEvents = "http://"+ipAddress+"/ECNotesWeb/getEvents.php";
}