package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class StudentDashboard extends Activity {

    private Spinner actionSpinner;
    String Sem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_dashboard);

        actionSpinner = findViewById(R.id.actionSpinner);
/*

        Intent i = getIntent();
        Sem = i.getStringExtra("Sem");
*/

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.dashboard_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        actionSpinner.setAdapter(adapter);

        actionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 1: // View Notes
                        Intent notesIntent = new Intent(StudentDashboard.this, SelectNotesView.class);
//                        notesIntent.putExtra("Sem", Sem);
                        startActivity(notesIntent);
                        break;
                    case 2: // View Projects
                        Intent projectsIntent = new Intent(StudentDashboard.this, SelectYearProject.class);
  //                      projectsIntent.putExtra("Sem", Sem);
                        startActivity(projectsIntent);
                        break;
                    case 3: // View Papers
                        Intent papersIntent = new Intent(StudentDashboard.this, SelectYearSyllabus.class);
    //                    papersIntent.putExtra("Sem", Sem);
                        startActivity(papersIntent);
                        break;
                    case 4: // View Notifications
                        Intent notifIntent = new Intent(StudentDashboard.this, SelectSemesterNotif.class);
      //                  notifIntent.putExtra("Sem", Sem);
                        startActivity(notifIntent);
                        break;
                    case 5: // View Events
                        Intent eventsIntent = new Intent(StudentDashboard.this, SelectYearEvent.class);
                        startActivity(eventsIntent);
                        break;
                    case 6:
                        finish();
                        break;
                    case 0: // Logout
                        //finish();
                        Toast.makeText(getApplicationContext(), "Select Your option", Toast.LENGTH_LONG).show();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }
}
