package com.proj.ecnotes;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class FacultyLogin extends AppCompatActivity {

    private EditText etFacUsername, etFacPassword;
    private Button btnFacLogin;
    private TextView regFac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.faculty_login);

        // Initialize views
        etFacUsername = findViewById(R.id.etFacUsername);
        etFacPassword = findViewById(R.id.etFacPassword);
        btnFacLogin = findViewById(R.id.btnFacLogin);
        regFac = findViewById(R.id.regFac);

        // Login Button Click Listener
        btnFacLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call method to perform login
                facultyLogin();
            }
        });

        // Register TextView Click Listener
        regFac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i = new Intent(FacultyLogin.this, RegisterFaculty.class);
               startActivity(i);
            }
        });
    }

    private void facultyLogin() {
        final String facId = etFacUsername.getText().toString().trim();
        final String password = etFacPassword.getText().toString().trim();

        // URL of the PHP script for faculty login
        String url = Config.facultyLogin; // Replace with your PHP script URL

        // Volley request to connect to PHP script
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean error = jsonObject.getBoolean("error");
                            if (!error) {
                                // Login successful, handle the response
                                Intent db = new Intent(FacultyLogin.this, FacultyDashboard.class);
                                startActivity(db);
                                Toast.makeText(getApplicationContext(), "Login successful!", Toast.LENGTH_SHORT).show();
                                // Proceed with next steps after successful login
                            } else {
                                // Login failed, display error message
                                String errorMsg = jsonObject.getString("message");
                                Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Error occurred during login request
                        Toast.makeText(getApplicationContext(), "Error occurred. Please try again later."+error, Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("facId", facId);
                params.put("password", password);
                return params;
            }
        };

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
