package com.proj.ecnotes;

public class AdminDashboard {
}
