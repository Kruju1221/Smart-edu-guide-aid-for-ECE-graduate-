package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ViewNotes extends Activity {

    ViewNotesAdapter adapter;
    ListView lstView;
    ArrayList<HashMap<String, String>> arraylist;

    String sem, unit, sub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_notes_students);

        Intent i = getIntent();
        sem = i.getStringExtra("sem");
        sub = i.getStringExtra("sub");
        unit = i.getStringExtra("unit");

        lstView = (ListView) findViewById(R.id.notesListView);
        getProperties();
    }

    private void getProperties() {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = Config.getNotes+"?sem="+sem+"&sub="+sub+"&unit="+unit;

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        arraylist = new ArrayList<HashMap<String, String>>();
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                HashMap<String, String> map = new HashMap<String, String>();
                                map.put("id", jsonObject.getString("id"));
                                map.put("file_name", jsonObject.getString("file_name"));
                                map.put("file_path", jsonObject.getString("file_path"));
                                map.put("semester", jsonObject.getString("semester"));
                                map.put("subject", jsonObject.getString("subject"));
                                map.put("unit", jsonObject.getString("unit"));

                                arraylist.add(map);
                            }
                            adapter = new ViewNotesAdapter(ViewNotes.this, arraylist);
                            lstView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

        queue.add(jsonArrayRequest);
    }
}