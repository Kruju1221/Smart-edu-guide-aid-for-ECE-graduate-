package com.proj.ecnotes;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewProjectsAdapter extends BaseAdapter {

    Context context;
    LayoutInflater inflater;

    ArrayList<HashMap<String, String>> arrLstData;

    HashMap<String, String> hashMapResult = new HashMap<String, String>();

    TextView projectName;
    TextView projectDescription;
    TextView projectYear;
    ImageView ivUploadedImage;
    String fileUrl;

    public ViewProjectsAdapter(Context context,
                            ArrayList<HashMap<String, String>> arraylist) {
        this.context = context;
        arrLstData = arraylist;
    }

    @Override
    public int getCount() {
        return arrLstData.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = inflater.inflate(R.layout.lst_items_projects, parent,
                false);

        hashMapResult = arrLstData.get(position);

        projectName = (TextView) itemView.findViewById(R.id.projectName);
        projectDescription = (TextView) itemView.findViewById(R.id.projectDescription);
        projectYear = (TextView) itemView.findViewById(R.id.projectYear);

        ivUploadedImage = (ImageView) itemView.findViewById(R.id.noteImageView);

        projectName.setText(hashMapResult.get("name"));
        projectDescription.setText(hashMapResult.get("description"));
        projectYear.setText(hashMapResult.get("year"));

        //sss

        /*Picasso.get()
                .load(imagepath)
                .into(ivUploadedImage);*/

        itemView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // Get the position
                hashMapResult = arrLstData.get(position);
                fileUrl = "http://"+Config.ipAddress+"/ECNotesWeb/"+hashMapResult.get("file_path");
                //fileUrl = hashMapResult.get("file_path");
                downloadFile(fileUrl);
                //Toast.makeText(context.getApplicationContext(),fileUrl, Toast.LENGTH_LONG).show();
                /*Intent intent = new Intent(context, ViewSingleProperty.class);
                intent.putExtra("id", hashMapResult.get("id"));
                intent.putExtra("name",hashMapResult.get("name"));
                intent.putExtra("description",hashMapResult.get("description"));
                intent.putExtra("author", hashMapResult.get("author"));*/


                //context.startActivity(intent);
            }
        });
        return itemView;
    }

    private void downloadFile(String fileUrl) {
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri uri = Uri.parse(fileUrl);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        downloadManager.enqueue(request);
    }
}
