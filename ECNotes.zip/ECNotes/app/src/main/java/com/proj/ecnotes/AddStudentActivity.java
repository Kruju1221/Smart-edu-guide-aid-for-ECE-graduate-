package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddStudentActivity extends Activity {

    private EditText usnEditText, nameEditText, emailEditText, phoneEditText, semesterEditText, branchEditText, passwordEditText;
    private Button addButton;

    private static final String ADD_STUDENT_URL = Config.addStudent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_student);

        usnEditText = findViewById(R.id.usnEditText);
        nameEditText = findViewById(R.id.nameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        semesterEditText = findViewById(R.id.semesterEditText);
        branchEditText = findViewById(R.id.branchEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        addButton = findViewById(R.id.addButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addStudent();
            }
        });
    }

    private void addStudent() {
        final String usn = usnEditText.getText().toString().trim();
        final String name = nameEditText.getText().toString().trim();
        final String email = emailEditText.getText().toString().trim();
        final String phone = phoneEditText.getText().toString().trim();
        final String semester = semesterEditText.getText().toString().trim();
        final String branch = branchEditText.getText().toString().trim();
        final String password = passwordEditText.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, ADD_STUDENT_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            String message = jsonResponse.getString("message");

                            if (success) {
                                Toast.makeText(AddStudentActivity.this, message, Toast.LENGTH_SHORT).show();
                                // Clear input fields after successful addition
                                clearFields();
                                Intent loginStudent = new Intent(AddStudentActivity.this, LoginStudentActivity.class);
                                startActivity(loginStudent);

                            } else {
                                Toast.makeText(AddStudentActivity.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(AddStudentActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley Error", "Error: " + error.getMessage());
                        Toast.makeText(AddStudentActivity.this, "Volley Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("usn", usn);
                params.put("name", name);
                params.put("email", email);
                params.put("phone", phone);
                params.put("semester", semester);
                params.put("branch", branch);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void clearFields() {
        usnEditText.setText("");
        nameEditText.setText("");
        emailEditText.setText("");
        phoneEditText.setText("");
        semesterEditText.setText("");
        branchEditText.setText("");
        passwordEditText.setText("");
    }
}

