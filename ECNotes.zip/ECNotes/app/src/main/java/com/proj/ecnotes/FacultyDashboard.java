package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FacultyDashboard extends Activity {

    private Button btnUploadNotes, btnUploadPapers, btnUploadProjects, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.faculty_dashboard);

        // Initialize buttons
        btnUploadNotes = findViewById(R.id.btnUploadNotes);
        btnUploadPapers = findViewById(R.id.btnUploadPapers);
        btnUploadProjects = findViewById(R.id.btnUploadProjects);
        btnLogout = findViewById(R.id.btnLogout);

        // Set click listeners for buttons
        btnUploadNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle upload notes button click
                // Implement your upload notes functionality here
                Toast.makeText(getApplicationContext(), "Upload Notes Clicked", Toast.LENGTH_SHORT).show();
                Intent addNotes = new Intent(getApplicationContext(), AddNotesActivity.class);
                startActivity(addNotes);
            }
        });

        btnUploadPapers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle upload papers button click
                // Implement your upload papers functionality here
                Toast.makeText(getApplicationContext(), "Upload Papers Clicked", Toast.LENGTH_SHORT).show();
                Intent addPapers = new Intent(getApplicationContext(), AddSyllabusActivity.class);
                startActivity(addPapers);

            }
        });

        btnUploadProjects.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle upload projects button click
                // Implement your upload projects functionality here
                Toast.makeText(getApplicationContext(), "Upload Projects Clicked", Toast.LENGTH_SHORT).show();
                Intent addProj = new Intent(getApplicationContext(), AddProjectsActivity.class);
                startActivity(addProj);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle logout button click
                // Implement logout functionality
                logout();
            }
        });
    }

    private void logout() {
        // Perform logout action, such as clearing session data, etc.
        // For example, you can navigate back to the login activity
        Intent intent = new Intent(getApplicationContext(), FacultyLogin.class);
        startActivity(intent);
        finish(); // Close this activity to prevent going back to FacultyDashboard on back press
    }
}
