package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterFaculty extends Activity {

    private EditText facultyIdEditText, fullNameEditText, branchEditText, designationEditText, emailEditText, phoneEditText, passwordEditText;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_faculty);

        // Initialize views
        facultyIdEditText = findViewById(R.id.facultyIdEditText);
        fullNameEditText = findViewById(R.id.fullNameEditText);
        branchEditText = findViewById(R.id.branchEditText);
        designationEditText = findViewById(R.id.designationEditText);
        emailEditText = findViewById(R.id.emailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerButton = findViewById(R.id.registerButton);

        // Register Button Click Listener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call method to register faculty
                registerFaculty();
            }
        });
    }

    private void registerFaculty() {
        final String facultyId = facultyIdEditText.getText().toString().trim();
        final String fullName = fullNameEditText.getText().toString().trim();
        final String branch = branchEditText.getText().toString().trim();
        final String designation = designationEditText.getText().toString().trim();
        final String email = emailEditText.getText().toString().trim();
        final String phone = phoneEditText.getText().toString().trim();
        final String password = passwordEditText.getText().toString().trim();

        String url = Config.registerFaculty; // Change this to your PHP script URL

        // Volley request to connect to PHP script
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean error = jsonObject.getBoolean("error");
                            if (!error) {
                                Toast.makeText(getApplicationContext(), "Faculty registered successfully!", Toast.LENGTH_SHORT).show();
                                Intent login = new Intent(getApplicationContext(), FacultyLogin.class);
                                startActivity(login);
                            } else {
                                String errorMsg = jsonObject.getString("message");
                                Toast.makeText(getApplicationContext(), errorMsg, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Error occurred. Please try again later."+error, Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("facultyId", facultyId);
                params.put("fullName", fullName);
                params.put("branch", branch);
                params.put("designation", designation);
                params.put("email", email);
                params.put("phone", phone);
                params.put("password", password);
                return params;
            }
        };

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(stringRequest);
    }
}