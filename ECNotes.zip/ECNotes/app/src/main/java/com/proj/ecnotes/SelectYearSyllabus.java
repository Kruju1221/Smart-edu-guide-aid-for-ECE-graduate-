package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SelectYearSyllabus extends Activity {

    private Spinner yearSpinner;
    private Button nextButton;

    private static final String LOAD_RANGE_URL = Config.getRanges; // Replace with your backend endpoint
    private static final String TAG = "SelectYearSyllabus";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_year_syllabus);

        yearSpinner = findViewById(R.id.yearSpinner);
        nextButton = findViewById(R.id.nextButton);

        loadRangeData();
        setupNextButton();
    }

    private void loadRangeData() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_RANGE_URL) // Replace with your backend endpoint to load range data
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(SelectYearSyllabus.this, "Failed to load range data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load range data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetRangeData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(SelectYearSyllabus.this, "Failed to load range data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load range data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetRangeData(String jsonData) {
        try {
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> rangeData = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                rangeData.add(jsonObject.getString("yearrange")); // Assuming "range" is the key for range data
            }

            ArrayAdapter<String> rangeAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, rangeData);
            rangeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            yearSpinner.setAdapter(rangeAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing range data: ", e);
            Toast.makeText(this, "Error parsing range data", Toast.LENGTH_SHORT).show();
        }
    }



    private void setupNextButton() {
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedYearRange = yearSpinner.getSelectedItem().toString();
                Intent intent = new Intent(SelectYearSyllabus.this, ViewSyllabus.class);
                intent.putExtra("selectedYearRange", selectedYearRange);
                startActivity(intent);
            }
        });
    }
}

