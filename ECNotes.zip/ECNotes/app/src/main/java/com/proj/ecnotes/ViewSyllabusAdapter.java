package com.proj.ecnotes;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewSyllabusAdapter extends BaseAdapter {

    Context context;
    LayoutInflater inflater;

    ArrayList<HashMap<String, String>> arrLstData;

    HashMap<String, String> hashMapResult = new HashMap<String, String>();

    TextView syllabusName;
    TextView syllabusYear;
    ImageView ivUploadedImage;
    String fileUrl;

    public ViewSyllabusAdapter(Context context,
                            ArrayList<HashMap<String, String>> arraylist) {
        this.context = context;
        arrLstData = arraylist;
    }

    @Override
    public int getCount() {
        return arrLstData.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = inflater.inflate(R.layout.lst_items_syllabus, parent,
                false);

        hashMapResult = arrLstData.get(position);

        syllabusName = (TextView) itemView.findViewById(R.id.syllabusName);
        syllabusYear = (TextView) itemView.findViewById(R.id.syllabusYear);

        ivUploadedImage = (ImageView) itemView.findViewById(R.id.noteImageView);

        syllabusName.setText(hashMapResult.get("file_name"));
        syllabusYear.setText(hashMapResult.get("yearrange"));

        //sss

        /*Picasso.get()
                .load(imagepath)
                .into(ivUploadedImage);*/

        itemView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // Get the position
                hashMapResult = arrLstData.get(position);
                fileUrl = "http://"+Config.ipAddress+"/ECNotesWeb/"+hashMapResult.get("file_path");
                //fileUrl = hashMapResult.get("file_path");
                downloadFile(fileUrl);
                //Toast.makeText(context.getApplicationContext(),fileUrl, Toast.LENGTH_LONG).show();
                /*Intent intent = new Intent(context, ViewSingleProperty.class);
                intent.putExtra("id", hashMapResult.get("id"));
                intent.putExtra("name",hashMapResult.get("name"));
                intent.putExtra("description",hashMapResult.get("description"));
                intent.putExtra("author", hashMapResult.get("author"));*/


                //context.startActivity(intent);
            }
        });
        return itemView;
    }

    private void downloadFile(String fileUrl) {
        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        Uri uri = Uri.parse(fileUrl);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        downloadManager.enqueue(request);
    }
}
