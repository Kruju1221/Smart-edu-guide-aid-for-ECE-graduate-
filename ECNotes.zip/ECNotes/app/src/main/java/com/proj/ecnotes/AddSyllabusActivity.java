package com.proj.ecnotes;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AddSyllabusActivity extends Activity {

    private static final int REQUEST_CODE_SELECT_FILE = 1;
    private static final MediaType MEDIA_TYPE_OCTET_STREAM = MediaType.parse("application/octet-stream");

    private Spinner spinnerRange;
    private Button uploadButton, selectFileButton;
    private TextView selectedFileTextView;

    private Uri selectedFileUri;
    private static final String UPLOAD_PAPER_URL = Config.addSyllabus; // Replace with your backend endpoint
    private static final String LOAD_RANGE_URL = Config.getRanges; // Replace with your backend endpoint


    private static final String TAG = "AddSyllabusActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_syllabus);

        // Initialize views
        spinnerRange = findViewById(R.id.spinnerRange);
        uploadButton = findViewById(R.id.uploadButton);
        selectFileButton = findViewById(R.id.selectFileButton);
        selectedFileTextView = findViewById(R.id.selectedFileTextView);

        // Set click listener for select file button
        selectFileButton.setOnClickListener(v -> selectFile());

        // Set click listener for upload button
        uploadButton.setOnClickListener(v -> uploadPaper());

        // Load range data
        loadRangeData();
    }

    private void loadRangeData() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_RANGE_URL) // Replace with your backend endpoint to load range data
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(AddSyllabusActivity.this, "Failed to load range data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load range data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetRangeData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(AddSyllabusActivity.this, "Failed to load range data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load range data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetRangeData(String jsonData) {
        try {
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> rangeData = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                rangeData.add(jsonObject.getString("yearrange")); // Assuming "range" is the key for range data
            }

            ArrayAdapter<String> rangeAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, rangeData);
            rangeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerRange.setAdapter(rangeAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing range data: ", e);
            Toast.makeText(this, "Error parsing range data", Toast.LENGTH_SHORT).show();
        }
    }

    public void selectFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, REQUEST_CODE_SELECT_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SELECT_FILE && resultCode == RESULT_OK) {
            selectedFileUri = data.getData();
            if (selectedFileUri != null) {
                selectedFileTextView.setText(getFileName(selectedFileUri));
            }
        }
    }

    private String getFileName(Uri uri) {
        String path = uri.getPath();
        if (path != null) {
            int lastIndex = path.lastIndexOf('/');
            return (lastIndex != -1) ? path.substring(lastIndex + 1) : "unknown_file";
        }
        return "unknown_file";
    }

    private void uploadPaper() {
        final String range = spinnerRange.getSelectedItem().toString().trim();

        // Validate input fields
        if (range.isEmpty()) {
            Toast.makeText(this, "Please select range", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedFileUri == null) {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
            try {
                // Create a temporary file to upload
                File tempFile = new File(getCacheDir(), getFileName(selectedFileUri));
                try (InputStream inputStream = getContentResolver().openInputStream(selectedFileUri);
                     FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = inputStream.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, len);
                    }
                }

                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(15, TimeUnit.SECONDS)
                        .writeTimeout(15, TimeUnit.SECONDS)
                        .readTimeout(15, TimeUnit.SECONDS)
                        .build();

                MultipartBody.Builder multipartBuilder = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("range", range)
                        .addFormDataPart("file", tempFile.getName(),
                                RequestBody.create(MEDIA_TYPE_OCTET_STREAM, tempFile));

                Request request = new Request.Builder()
                        .url(UPLOAD_PAPER_URL)
                        .post(multipartBuilder.build())
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful()) {
                    runOnUiThread(() -> Toast.makeText(this, "Upload Successful", Toast.LENGTH_SHORT).show());
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Upload Failed", Toast.LENGTH_SHORT).show());
                }

            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}
