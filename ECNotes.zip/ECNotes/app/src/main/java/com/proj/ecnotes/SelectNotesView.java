package com.proj.ecnotes;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SelectNotesView extends AppCompatActivity {

    private static final String TAG = "SelectNotesView";

    private Spinner semesterSpinner, subjectSpinner, unitsSpinner;
    private Button buttonLoadNotes;

    private static final String LOAD_SEMESTER_URL = Config.getSemesters;
    private static final String LOAD_SUBJECTS_URL = Config.getSubjects;
    private static final String LOAD_UNITS_URL = Config.getUnits;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_notes_view);

        semesterSpinner = findViewById(R.id.semesterSpinner);
        subjectSpinner = findViewById(R.id.subjectSpinner);
        unitsSpinner = findViewById(R.id.unitsSpinner);

        buttonLoadNotes = findViewById(R.id.buttonLoadNotes);



        loadSemesterData();
        loadUnitsData();

        buttonLoadNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sem = semesterSpinner.getSelectedItem().toString().trim();
                String sub = subjectSpinner.getSelectedItem().toString().trim();
                String unit = unitsSpinner.getSelectedItem().toString().trim();

                Intent vn = new Intent(SelectNotesView.this, ViewNotes.class);
                vn.putExtra("sem",sem);
                vn.putExtra("sub",sub);
                vn.putExtra("unit",unit);
                startActivity(vn);
            }
        });


        semesterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedSemester = parentView.getItemAtPosition(position).toString();
                loadSubjectsData(selectedSemester);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing if nothing is selected
            }
        });

        subjectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedSubject = parentView.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing if nothing is selected
            }
        });

    }

    private void loadSemesterData() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_SEMESTER_URL) // replace with your backend endpoint
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(SelectNotesView.this, "Failed to load semester data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load semester data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetSemesterData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(SelectNotesView.this, "Failed to load semester data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load semester data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetSemesterData(String jsonData) {
        try {
            Log.d(TAG, "Semester JSON Data: " + jsonData);
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> semesters = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                semesters.add(jsonObject.getString("semester"));
            }

            ArrayAdapter<String> semesterAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, semesters);
            semesterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            semesterSpinner.setAdapter(semesterAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing semester data: ", e);
            Toast.makeText(this, "Error parsing semester data", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadSubjectsData(String selectedSemester) {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_SUBJECTS_URL + "?semester=" + selectedSemester) // URL to load subjects data based on selected semester
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(SelectNotesView.this, "Failed to load subjects data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load subjects data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetSubjectsData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(SelectNotesView.this, "Failed to load subjects data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load subjects data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetSubjectsData(String jsonData) {
        try {
            Log.d(TAG, "Subjects JSON Data: " + jsonData);
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> subjects = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                subjects.add(jsonObject.getString("subject"));
            }

            ArrayAdapter<String> subjectAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, subjects);
            subjectAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            subjectSpinner.setAdapter(subjectAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing subject data: ", e);
            Toast.makeText(this, "Error parsing subject data", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadUnitsData() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url(LOAD_UNITS_URL) // URL to load units data based on selected subject
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(SelectNotesView.this, "Failed to load units data", Toast.LENGTH_SHORT).show());
                Log.e(TAG, "Failed to load units data: ", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    runOnUiThread(() -> parseAndSetUnitsData(responseData));
                } else {
                    runOnUiThread(() -> Toast.makeText(SelectNotesView.this, "Failed to load units data", Toast.LENGTH_SHORT).show());
                    Log.e(TAG, "Failed to load units data. Response code: " + response.code());
                }
            }
        });
    }

    private void parseAndSetUnitsData(String jsonData) {
        try {
            Log.d(TAG, "Units JSON Data: " + jsonData);
            JSONArray jsonArray = new JSONArray(jsonData);

            List<String> units = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                units.add(jsonObject.getString("unitname"));
            }

            ArrayAdapter<String> unitsAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, units);
            unitsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            unitsSpinner.setAdapter(unitsAdapter);

        } catch (Exception e) {
            Log.e(TAG, "Error parsing units data: ", e);
            Toast.makeText(this, "Error parsing units data", Toast.LENGTH_SHORT).show();
        }
    }

}
