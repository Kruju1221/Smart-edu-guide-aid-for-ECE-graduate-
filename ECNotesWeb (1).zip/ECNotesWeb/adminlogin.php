<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "ecnotes";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect to Database');

mysqli_select_db($db_con, $DB_NAME);

// Handle POST data
$username = $_POST['username'];
$password = $_POST['password'];

// Validate the input fields
if (empty($username) || empty($password)) {
    $response['success'] = false;
    $response['message'] = "Please fill all required fields.";
    echo json_encode($response);
    exit();
}

// Check admin credentials
$sql = "SELECT * FROM admins WHERE username ='$username' AND password ='$password'";
$result = mysqli_query($db_con, $sql);
$row = mysqli_fetch_array($result);

if ($row) {
    $response['success'] = true;
    $response['message'] = "Login successful";
    echo json_encode($response);
} else {
    $response['success'] = false;
    $response['message'] = "Invalid username or password";
    echo json_encode($response);
}

mysqli_close($db_con);
?>
