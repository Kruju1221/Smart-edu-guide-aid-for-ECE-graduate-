<?php
// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecnotes";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch distinct semesters from the syllabus table for filtering
$semesters_sql = "SELECT DISTINCT yearrange FROM syllabus";
$semesters_result = $conn->query($semesters_sql);

// Default query for fetching syllabus records
$syllabus_sql = "SELECT * FROM syllabus";
$selected_semester = "";

// If a semester is selected, update the query to filter by that semester
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['yearrange'])) {
    $selected_semester = $_POST['yearrange'];
    $syllabus_sql = "SELECT * FROM syllabus WHERE yearrange = '$selected_semester'";
}

$syllabus_result = $conn->query($syllabus_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Syllabus - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Student Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="studentDashboard.php">Dashboard</a>  <!-- Link to Logout -->
                </li>
				<li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>  <!-- Link to Logout -->
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h3>View Syllabus</h3>

        <!-- Form for filtering by semester -->
        <form method="post" class="mb-3">
            <div class="form-group">
                <label for="yearrange">Filter by Semester</label>
                <select class="form-control" id="semester" name="yearrange" onchange="this.form.submit()">
                    <option value="">Select Year Range</option>
                    <?php
                    if ($semesters_result->num_rows > 0) {
                        while ($row = $semesters_result->fetch_assoc()) {
                            $yearrange = $row['yearrange'];
                            $selected = ($selected_semester == $yearrange) ? "selected" : "";
                            echo "<option value='$yearrange' $selected>$yearrange</option>";
                        }
                    }
                    ?>
                </select>
            </div>
        </form>

        <!-- Display the syllabus in a table -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Year</th>
                    <th>File Name</th>
                    <th>Download</th>  <!-- Only download option -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($syllabus_result->num_rows > 0) {
                    while ($row = $syllabus_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['yearrange'] . "</td>";
                        echo "<td>" . $row['file_name'] . "</td>";
                        echo "<td>
                                <a href='uploads/syllabus/" . $row['file_name'] . "' class='btn btn-info' download>Download</a>
                             </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>No syllabus found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <a href="studentDashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>

</body>
</html>

<?php
$conn->close(); // Close the database connection
?>