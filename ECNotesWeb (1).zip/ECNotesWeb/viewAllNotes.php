<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "ecnotes";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect to Database');

mysqli_select_db($db_con, $DB_NAME);

// Select all notes
$sql = "SELECT * FROM notes";
$result = mysqli_query($db_con, $sql);

$response = array();

if (mysqli_num_rows($result) > 0) {
    // Loop through each row
    while ($row = mysqli_fetch_assoc($result)) {
        // Add note details to response array
        $response[] = $row;
    }
    // Send JSON response with all notes
    echo json_encode($response);
} else {
    // No notes found
    $response['success'] = false;
    $response['message'] = "No notes found";
    echo json_encode($response);
}

mysqli_close($db_con);
?>
