<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root"; // Replace with your database username
$DB_PASS = ""; // Replace with your database password
$DB_NAME = "ecnotes"; // Replace with your database name

// Connect to the database
$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS, $DB_NAME) or die('Unable to Connect to Database');

// Handle POST data
$facultyId = $_POST['facultyId'];
$fullName = $_POST['fullName'];
$branch = $_POST['branch'];
$designation = $_POST['designation'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$phone = $_POST['phone'];

// Check if username already exists
$check_sql = "SELECT * FROM users WHERE username = '$username'";
$check_result = $conn->query($check_sql);

if ($check_result->num_rows > 0) {
    echo "<div class='alert alert-danger text-center mt-4'>Username already exists. Please choose another.</div>";
} else {
    $insert_sql = "INSERT INTO users (username, password, email, phone, role) 
   VALUES ('$username', '$password', '$email', '$phone', 'student')";

    if ($conn->query($insert_sql) === TRUE) {
				$response['error'] = false;
				$response['message'] = "Faculty registered successfully";
				echo json_encode($response);
    } else {
				$response['error'] = true;
				$response['message'] = "Unable to register faculty: " . mysqli_error($db_con);
				echo json_encode($response);
    }
}

$conn->close();


?>
