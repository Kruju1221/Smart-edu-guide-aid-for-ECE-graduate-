<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register Faculty - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">EC Notes</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="student.php">Student</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="faculty.php">Faculty</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin.php">Admin</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Register Faculty</div>
                    <div class="card-body">
                        <form method="post">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
							<div class="form-group">
                                <label for="username">Full Name</label>
                                <input type="text" class="form-control" id="fullname" name="fullname" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="text" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name = "email"required>
                            </div>
							<div class="form-group">
    <label for="branch">Branch</label>
    <input type="text" class="form-control" id="branch" name="branch" required>
</div>
<div class="form-group">
    <label for="designation">Designation</label>
    <input type="text" class="form-control" id="designation" name="designation" required>
</div>

                            <button type="submit" class="btn btn-primary">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $db_user = "root";
    $db_password = "";
    $dbname = "ecnotes";

    $conn = new mysqli($servername, $db_user, $db_password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $facultyid = $_POST['username']; // Assuming username is used as facultyid
    $fullname = $_POST['fullname'];
    $branch = $_POST['branch']; // Add branch input field to your HTML form
    $designation = $_POST['designation']; // Add designation input field to your HTML form
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    // Check if the facultyid already exists
    $check_sql = "SELECT * FROM faculty WHERE facultyid = '$facultyid'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        echo "<div class='alert alert-danger text-center mt-4'>Faculty ID already exists. Please choose another.</div>";
    } else {
        $insert_sql = "INSERT INTO faculty (facultyid, fullname, branch, designation, email, phone, password) VALUES ('$facultyid', '$fullname', '$branch', '$designation', '$email', '$phone', '$password')";
        if ($conn->query($insert_sql) === TRUE) {
            echo "<div class='alert alert-success text-center mt-4'>Registration successful! You can now login.</div>";
        } else {
            echo "<div class='alert alert-danger text-center mt-4'>Registration failed. Please try again.</div>";
        }
    }

    $conn->close();
}
?>


</body>
</html>
