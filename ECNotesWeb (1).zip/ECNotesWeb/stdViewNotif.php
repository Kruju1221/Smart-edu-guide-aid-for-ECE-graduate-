<?php
// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecnotes";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch distinct semesters from the notifications table for filtering
$semesters_sql = "SELECT DISTINCT semester FROM notifications";
$semesters_result = $conn->query($semesters_sql);

// Default query for fetching all notifications
$notifications_sql = "SELECT * FROM notifications";
$selected_recipient = "";

// If a semester (recipient) is selected, update the query to filter by that
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['semester'])) {
    $selected_recipient = $_POST['semester'];
    $notifications_sql = "SELECT * FROM notifications WHERE semester = '$selected_recipient'";
}

$notifications_result = $conn->query($notifications_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Notifications - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Student Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="studentDashboard.php">Dashboard</a>  <!-- Link to Logout -->
                </li>
				<li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>  <!-- Link to Logout -->
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h3>View Notifications</h3>

        <!-- Form for filtering by recipient (semester) -->
        <form method="post" class="mb-3">
            <div class="form-group">
                <label for="recipient">Filter by Semester</label>
                <select class="form-control" id="semester" name="semester" onchange="this.form.submit()">
                    <option value="">All Semesters</option>
                    <?php
                    if ($semesters_result->num_rows > 0) {
                        while ($row = $semesters_result->fetch_assoc()) {
                            $semester = $row['semester'];
                            $selected = ($selected_recipient == $semester) ? "selected" : "";
                            echo "<option value='$semester' $selected>$semester</option>";
                        }
                    }
                    ?>
                </select>
            </div>
        </form>

        <!-- Display the notifications in a table -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Message</th>
                    <th>Created At</th>
                    <th>Semester</th>  <!-- For the semester/recipient -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($notifications_result->num_rows > 0) {
                    while ($row = $notifications_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['title'] . "</td>";
                        echo "<td>" . $row['message'] . "</td>";
                        echo "<td>" . $row['created_at'] . "</td>";
                        echo "<td>" . $row['semester'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No notifications found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <a href="studentDashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>

</body>
</html>

<?php
$conn->close(); // Close the database connection
