<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['admin_username'])) {
    header("Location: admin.php");  // Redirect to admin login if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Admin Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
			 <li class="nav-item">
                    <a class="nav-link" href="adminDashboard.php">Dashboard</a>  <!-- Link to Logout -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>  <!-- Link to Logout -->
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <!-- Panel for viewing students -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Students</h5>
                        <p class="card-text">View and manage all students in the system.</p>
                        <a href="viewStudents.php" class="btn btn-primary">View Students</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing faculties -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Faculties</h5>
                        <p class="card-text">View and manage all faculty members.</p>
                        <a href="viewFaculties.php" class="btn btn-primary">View Faculties</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing events -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Events</h5>
                        <p class="card-text">View all events and manage them.</p>
                        <a href="viewEvents.php" class="btn btn-primary">View Events</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <!-- Panel for viewing projects -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Projects</h5>
                        <p class="card-text">View and manage all projects.</p>
                        <a href="viewProjects.php" class="btn btn-primary">View Projects</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing notes -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Notes</h5>
                        <p class="card-text">View and manage all course notes.</p>
                        <a href="viewNotes.php" class="btn btn-primary">View Notes</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing syllabus -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Syllabus</h5>
                        <p class="card-text">View and manage all syllabus documents.</p>
                        <a href="viewSyllabus.php" class="btn btn-primary">View Syllabus</a>
                    </div>
                </div>
            </div>
        </div>
		
		
		
		
		
		
		<div class="row mt-4">
            <!-- Panel for viewing projects -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Notificatons</h5>
                        <p class="card-text">View and manage all Notifications.</p>
                        <a href="viewNotifications.php" class="btn btn-primary">View Notifications</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing notes -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Logout</h5>
                        <p class="card-text">Invalidate all sessions and logs you out.</p>
                        <a href="logout.php" class="btn btn-primary">Logout</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing syllabus -->
           
        </div>
		
		
    </div>

</body>
</html>
