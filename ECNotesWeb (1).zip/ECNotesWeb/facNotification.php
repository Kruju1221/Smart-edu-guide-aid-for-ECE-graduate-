<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Notification - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="facDashboard.php">Faculty Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="facDashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Send Notification</div>
                    <div class="card-body">
                        <form method="post">
                            <div class="form-group">
                                <label for="title">Title</label>
                                <input type="text" class="form-control" id="title" name="title" required>
                            </div>
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea class="form-control" id="message" name="message" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="recipient">Recipient Semester</label>
                                <select class="form-control" name="semester">
                                    <option value="">Select Semester</option>
                                    <?php
                                    // Connect to the database
                                    $conn = new mysqli("localhost", "root", "", "ecnotes");
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    // Fetch semesters from the database
                                    $sql = "SELECT id, semester FROM semesters";
                                    $result = $conn->query($sql);

                                    // Check if there are semesters
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<option value='" . $row['semester'] . "'>" . $row['semester'] . "</option>";
                                        }
                                    }

                                    // Add an option for all semesters
                                    echo "<option value='All'>All</option>";

                                    $conn->close();
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Send Notification</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "localhost";
        $db_username = "root";
        $db_password = "";
        $dbname = "ecnotes";

        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $title = $_POST['title'];
        $message = $_POST['message'];
        $semester = $_POST['semester'];

        $insert_sql = "INSERT INTO notifications (title, message, semester) 
                       VALUES ('$title', '$message', '$semester')";

        if ($conn->query($insert_sql) === TRUE) {
            echo "<div class='alert alert-success text-center mt-4'>Notification sent successfully!</div>";
        } else {
            echo "<div class='alert alert-danger text-center mt-4'>Error: " . $conn->error . "</div>";
        }

        $conn->close();
    }
    ?>

</body>
</html>
