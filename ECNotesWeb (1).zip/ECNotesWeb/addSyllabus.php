<?php
// Database connection settings
$host = 'localhost';
$dbname = 'ecnotes';
$user = 'root';
$password = '';

// Connect to the MySQL database
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$target_dir = "uploads/syllabus/";

// Ensure the uploads directory exists
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true);
}

// Retrieve form data
$range = isset($_POST['range']) ? $_POST['range'] : '';

// Retrieve file data
$file = $_FILES['file'];
$file_name = $file['name'];
$file_tmp = $file['tmp_name'];
$target_file = $target_dir . basename($file_name);

// Move the uploaded file to the target directory
if (move_uploaded_file($file_tmp, $target_file)) {
    // Insert data into the database
    $sql = "INSERT INTO syllabus (file_name, file_path, yearrange) 
            VALUES ('$file_name', '$target_file','$range')";

    if ($conn->query($sql) === TRUE) {
        $response = [
            'status' => 'success',
            'message' => 'File uploaded and data inserted successfully',
            'file_name' => $file_name
        ];

        echo json_encode($response);
    } else {
        http_response_code(500);
        $response = [
            'status' => 'error',
            'message' => 'Database insertion failed: ' . $conn->error
        ];
        echo json_encode($response);
    }
} else {
    http_response_code(500);
    $response = [
        'status' => 'error',
        'message' => 'File upload failed'
    ];
    echo json_encode($response);
}

$conn->close();
?>
