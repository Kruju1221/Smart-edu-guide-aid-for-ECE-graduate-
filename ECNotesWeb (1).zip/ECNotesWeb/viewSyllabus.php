<?php
// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecnotes";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete requests
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $syllabus_id = $_POST['delete'];
    $delete_sql = "DELETE FROM syllabus WHERE id = $syllabus_id";

    if ($conn->query($delete_sql) === TRUE) {
        echo "<div class='alert alert-success'>Syllabus deleted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error deleting syllabus: " . $conn->error . "</div>";
    }
}

// Fetch all syllabus records
$sql = "SELECT * FROM syllabus";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Syllabus - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container mt-5">
        <h3>View Syllabus</h3>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Year Range</th>
                    <th>File Name</th>
                    <th>Action</th>  <!-- For delete and download buttons -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['yearrange'] . "</td>";
                        echo "<td>" . $row['file_name'] . "</td>";
                        echo "<td>
                                <form method='post' style='display:inline-block;'>
                                    <button type='submit' name='delete' value='" . $row['id'] . "' class='btn btn-danger'>Delete</button>
                                </form>
                                <a href='uploads/syllabus/" . $row['file_name'] . "' class='btn btn-info' download>Download</a>
                             </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>No syllabus records found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <a href="adminDashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>

</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
