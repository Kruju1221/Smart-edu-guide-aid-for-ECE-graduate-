<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload Syllabus - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="facultyDashboard.php">Faculty Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="facDashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Upload Syllabus</div>
                    <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="yearrange">Year Range</label>
                                <select class="form-control" id="yearrange" name="yearrange" required>
                                    <option value="">Select Year Range</option>
                                    <?php
                                    // Fetch year ranges from the syllabusyear table
                                    $conn = new mysqli("localhost", "root", "", "ecnotes");
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }
                                    $sql = "SELECT id, yearrange FROM syllabusyear";
                                    $result = $conn->query($sql);
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<option value='".$row['yearrange']."'>".$row['yearrange']."</option>";
                                    }
                                    $conn->close();
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="file">Upload File</label>
                                <input type="file" class="form-control-file" id="file" name="file" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Upload</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $servername = "localhost";
        $db_username = "root";
        $db_password = "";
        $dbname = "ecnotes";

        // Create a connection to the database
        $conn = new mysqli($servername, $db_username, $db_password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve form data
        $yearrange = $_POST['yearrange'];

        // Handle file upload
        $upload_dir = "uploads/syllabus/";
        $file_name = basename($_FILES['file']['name']);
        $file_path = $upload_dir . $file_name;

        if (move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
            $insert_sql = "INSERT INTO syllabus (file_name, file_path, yearrange) 
                           VALUES ('$file_name', '$file_path', '$yearrange')";

            if ($conn->query($insert_sql) === TRUE) {
                echo "<div class='alert alert-success text-center mt-4'>Syllabus uploaded successfully!</div>";
            } else {
                echo "<div class='alert alert-danger text-center mt-4'>Error: " . $conn->error . "</div>";
            }
        } else {
            echo "<div class='alert alert-danger text-center mt-4'>File upload failed. Please try again.</div>";
        }

        $conn->close(); // Close the connection
    }
    ?>

</body>
</html>
