<?php
// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecnotes";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if a delete request is received
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $user_id = $_POST['delete'];
    $delete_sql = "DELETE FROM faculty WHERE id = $user_id";

    if ($conn->query($delete_sql) === TRUE) {
        echo "<div class='alert alert-success'>Faculty record deleted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error deleting record: " . $conn->error . "</div>";
    }
}

// Fetch faculties with role "faculty"
$sql = "SELECT * FROM faculty";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Faculties - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Admin Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
			 <li class="nav-item">
                    <a class="nav-link" href="adminDashboard.php">Dashboard</a>  <!-- Link to Logout -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>  <!-- Link to Logout -->
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h3>View Faculties</h3>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Designation</th>
                    <th>Action</th>  <!-- For the delete button -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['facultyid'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . $row['phone'] . "</td>";
                        echo "<td>" . $row['designation'] . "</td>";
                        echo "<td>
                                <form method='post'>
                                    <button type='submit' name='delete' value='" . $row['id'] . "' class='btn btn-danger'>Delete</button>
                                </form>
                             </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No faculties found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <a href="adminDashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>

</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
