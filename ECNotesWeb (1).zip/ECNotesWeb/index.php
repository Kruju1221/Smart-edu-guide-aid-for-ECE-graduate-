<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">EC Notes</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="student.php">Student</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="faculty.php">Faculty</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin.php">Admin</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Student</h5>
                        <p class="card-text">Access course notes, assignments, and other study materials.</p>
                        <a href="student.php" class="btn btn-primary">Go to Student</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Faculty</h5>
                        <p class="card-text">Manage courses, upload notes, and track student progress.</p>
                        <a href="faculty.php" class="btn btn-primary">Go to Faculty</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Admin</h5>
                        <p class="card-text">Manage users, courses, and system settings.</p>
                        <a href="admin.php" class="btn btn-primary">Go to Admin</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
