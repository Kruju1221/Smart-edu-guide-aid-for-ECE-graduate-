<?php
session_start();

// Unset all session variables


// Destroy the session
session_destroy();

// Redirect to the login page (or any other desired page)
header("Location: index.php"); // Change this to your login or home page
exit();
?>
