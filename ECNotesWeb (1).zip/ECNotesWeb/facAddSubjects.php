<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Subjects - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">EC Notes</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="facDashboard.php">Faculty Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Add Subject</h2>
        <?php
        // Database connection details
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ecnotes";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch semesters
        $semesters = [];
        $sql = "SELECT id, semester FROM semesters";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $semesters[] = $row;
            }
        }

        // Handle form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $semester_id = $_POST["semester"];
            $subject = $_POST["subject"];

            // Get the semester value
            $stmt = $conn->prepare("SELECT semester FROM semesters WHERE id = ?");
            $stmt->bind_param("i", $semester_id);
            $stmt->execute();
            $stmt->bind_result($semester);
            $stmt->fetch();
            $stmt->close();

            // Prepare and bind
            $stmt = $conn->prepare("INSERT INTO subjects (semester, subject) VALUES (?, ?)");
            $stmt->bind_param("ss", $semester, $subject);

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>New subject added successfully.</div>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
            }

            $stmt->close();
        }

        $conn->close();
        ?>

        <form action="facAddSubjects.php" method="post">
            <div class="form-group">
                <label for="semester">Semester:</label>
                <select class="form-control" id="semester" name="semester" required>
                    <option value="">Select Semester</option>
                    <?php foreach($semesters as $sem): ?>
                        <option value="<?php echo $sem['id']; ?>"><?php echo $sem['semester']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="subject">Subject:</label>
                <input type="text" class="form-control" id="subject" name="subject" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Subject</button>
        </form>
    </div>

</body>
</html>
