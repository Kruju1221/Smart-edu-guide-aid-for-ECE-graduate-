<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "ecnotes";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect to Database');

mysqli_select_db($db_con, $DB_NAME);

// Handle POST data
$usn = $_POST['usn'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$semester = $_POST['semester'];
$branch = $_POST['branch'];
$password = $_POST['password'];

// Validate the input fields
if (empty($usn) || empty($name) || empty($email) || empty($phone) || empty($semester) || empty($branch) || empty($password)) {
    $response['success'] = false;
    $response['message'] = "Please fill all required fields.";
    echo json_encode($response);
    exit();
}

// Insert data into the database
$insert_query = "INSERT INTO student (usn, name, email, phone, semester, branch, password) 
                 VALUES ('$usn', '$name', '$email', '$phone', '$semester', '$branch', '$password')";

if (mysqli_query($db_con, $insert_query)) {
    $response['success'] = true;
    $response['message'] = "Student added successfully";
    echo json_encode($response);
} else {
    $response['success'] = false;
    $response['message'] = "Unable to add student: " . mysqli_error($db_con);
    echo json_encode($response);
}

mysqli_close($db_con);
?>
