<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root"; // Replace with your database username
$DB_PASS = ""; // Replace with your database password
$DB_NAME = "ecnotes"; // Replace with your database name

// Connect to the database
$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS, $DB_NAME) or die('Unable to Connect to Database');

// Handle POST data
$facultyId = $_POST['facultyId'];
$fullName = $_POST['fullName'];
$branch = $_POST['branch'];
$designation = $_POST['designation'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

// Validate the input fields
if (empty($facultyId) || empty($fullName) || empty($branch) || empty($designation) || empty($email) || empty($phone) || empty($password)) {
    $response['error'] = true;
    $response['message'] = "Please fill all required fields.";
    echo json_encode($response);
    exit();
}

// Check if the faculty ID or email already exists
$check_query = "SELECT * FROM faculty WHERE facultyid = '$facultyId' OR email = '$email'";
$check_result = mysqli_query($db_con, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    $response['error'] = true;
    $response['message'] = "Faculty ID or Email already exists.";
    echo json_encode($response);
    exit();
}

// Insert data into the database
$insert_query = "INSERT INTO faculty (facultyid, fullname, branch, designation, email, phone, password) 
                 VALUES ('$facultyId', '$fullName', '$branch', '$designation', '$email', '$phone', '$password')";

if (mysqli_query($db_con, $insert_query)) {
    $response['error'] = false;
    $response['message'] = "Faculty registered successfully";
    echo json_encode($response);
} else {
    $response['error'] = true;
    $response['message'] = "Unable to register faculty: " . mysqli_error($db_con);
    echo json_encode($response);
}

// Close database connection
mysqli_close($db_con);
?>
