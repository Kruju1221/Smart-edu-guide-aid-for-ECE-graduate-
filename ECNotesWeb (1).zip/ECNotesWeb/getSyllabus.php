<?php

		$db_host  = "localhost";
		$db_uid  = "root";
		$db_pass = "";
		$db_name  = "ecnotes";
       
		$db_con = mysqli_connect($db_host,$db_uid,$db_pass) or die('Unable to Connect to Database');

		mysqli_select_db($db_con,$db_name);
	
		$range = $_GET['range'];
 		$sql = "select * from syllabus where yearrange = '$range'";
 
		$result = mysqli_query($db_con,$sql);
		while($row=mysqli_fetch_assoc($result))
		{
			$output[]=$row;
		}
		print(json_encode($output));


 mysqli_close($db_con);   
?>