<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecnotes";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve POST parameters
$username = $_POST["username"];
$password = $_POST["password"];
$role = $_POST["role"];

// Validate credentials
$sql = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $password, $role);
$stmt->execute();
$result = $stmt->get_result();

$response = array();

if ($result->num_rows > 0) {
    $response["success"] = true;
	$response["role"] = $role;
	
} else {
    $response["success"] = false;
}

echo json_encode($response);

$conn->close();
?>
