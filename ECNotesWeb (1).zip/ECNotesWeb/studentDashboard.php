<?php
session_start();

// Check if the student is logged in
if (!isset($_SESSION['student_username'])) {
    header("Location: student.php");  // Redirect to student login if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Student Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="studentDashboard.php">Dashboard</a>  <!-- Link to Logout -->
                </li>
				<li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>  <!-- Link to Logout -->
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <!-- Panel for viewing notes -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Notes</h5>
                        <p class="card-text">View course notes for your subjects.</p>
                        <a href="stdViewNotes.php" class="btn btn-primary">View Notes</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing syllabus -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Syllabus</h5>
                        <p class="card-text">View the syllabus for your courses.</p>
                        <a href="stdViewSyllabus.php" class="btn btn-primary">View Syllabus</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing projects -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Projects</h5>
                        <p class="card-text">View student projects and assignments.</p>
                        <a href="stdViewProjects.php" class="btn btn-primary">View Projects</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <!-- Panel for viewing notifications -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Notifications</h5>
                        <p class="card-text">View important notifications and announcements.</p>
                        <a href="stdViewNotif.php" class="btn btn-primary">View Notifications</a>
                    </div>
                </div>
            </div>

            <!-- Panel for viewing events -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">View Events</h5>
                        <p class="card-text">View upcoming events and schedules.</p>
                        <a href="stdViewEvents.php" class="btn btn-primary">View Events</a>
                    </div>
                </div>
            </div>
			
			<div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"> Logout </h5>
                        <p class="card-text">Expires all Sessions and logs you out to login screen again.</p>
                        <a href="Logout.php" class="btn btn-primary">View Events</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
