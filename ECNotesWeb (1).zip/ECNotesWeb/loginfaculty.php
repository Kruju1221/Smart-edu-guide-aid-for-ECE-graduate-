<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root"; // Replace with your database username
$DB_PASS = ""; // Replace with your database password
$DB_NAME = "ecnotes"; // Replace with your database name

// Connect to the database
$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS, $DB_NAME) or die('Unable to Connect to Database');

// Handle POST data
$facId = $_POST['facId'];
$password = $_POST['password'];

// Validate the input fields
if (empty($facId) || empty($password)) {
    $response['error'] = true;
    $response['message'] = "Please provide faculty ID and password.";
    echo json_encode($response);
    exit();
}

// Check if the faculty ID and password match in the database
$query = "SELECT * FROM faculty WHERE facultyid = '$facId' AND password = '$password'";
$result = mysqli_query($db_con, $query);

if (mysqli_num_rows($result) > 0) {
    // Faculty login successful
    $response['error'] = false;
    $response['message'] = "Login successful";
    echo json_encode($response);
} else {
    // Faculty login failed
    $response['error'] = true;
    $response['message'] = "Invalid faculty ID or password.";
    echo json_encode($response);
}

// Close database connection
mysqli_close($db_con);
?>
