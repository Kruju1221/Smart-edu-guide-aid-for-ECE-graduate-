<?php
// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecnotes";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete requests
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $note_id = $_POST['delete'];
    $delete_sql = "DELETE FROM notes WHERE id = $note_id";

    if ($conn->query($delete_sql) === TRUE) {
        echo "<div class='alert alert-success'>Note deleted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error deleting note: " . $conn->error . "</div>";
    }
}

// Fetch all notes
$sql = "SELECT * FROM notes";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Notes - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Admin Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
			 <li class="nav-item">
                    <a class="nav-link" href="adminDashboard.php">Dashboard</a>  <!-- Link to Logout -->
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>  <!-- Link to Logout -->
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h3>View Notes</h3>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Subject</th>
                    <th>Unit</th>
                    <th>Semester</th>
                    <th>File Name</th>
                    <th>Action</th>  <!-- For the delete and download buttons -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['subject'] . "</td>";
                        echo "<td>" . $row['unit'] . "</td>";
                        echo "<td>" . $row['semester'] . "</td>";
                        echo "<td>" . $row['file_name'] . "</td>";
                        echo "<td>
                                <form method='post' style='display:inline-block;'>
                                    <button type='submit' name='delete' value='" . $row['id'] . "' class='btn btn-danger'>Delete</button>
                                </form>
                                <a href='uploads/notes/" . $row['file_name'] . "' class='btn btn-info' download>Download</a>
                             </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>No notes found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <a href="adminDashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>

</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
