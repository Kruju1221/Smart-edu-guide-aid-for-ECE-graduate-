<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Faculty Dashboard - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">EC Notes</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="facultyDashboard.php">Faculty Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row">
            <div class="row mt-4">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Unit</h5>
                        <p class="card-text">Add a new unit for courses.</p>
                        <a href="facAddUnit.php" class="btn btn-primary">Go to Add Unit</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Range</h5>
                        <p class="card-text">Add a new range for grades or assessments.</p>
                        <a href="facAddRange.php" class="btn btn-primary">Go to Add Range</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Semester</h5>
                        <p class="card-text">Add a new semester for courses.</p>
                        <a href="facAddSemester.php" class="btn btn-primary">Go to Add Semester</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Add Subjects</h5>
                        <p class="card-text">Add new subjects for courses.</p>
                        <a href="facAddSubjects.php" class="btn btn-primary">Go to Add Subjects</a>
                    </div>
                </div>
            </div>
        </div>
		</div>
		<div class="row">
			<div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Upload Notes</h5>
                        <p class="card-text">Upload course notes for students to access.</p>
                        <a href="facNoteUpload.php" class="btn btn-primary">Go to Upload Notes</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Upload Syllabus</h5>
                        <p class="card-text">Upload Syllabus according to semester.</p>
                        <a href="facUploadSyllabus.php" class="btn btn-primary">Go to Upload Papers</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Upload Projects</h5>
                        <p class="card-text">Upload student projects and assignments.</p>
                        <a href="facUploadProject.php" class="btn btn-primary">Go to Upload Projects</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Send Notifications</h5>
                        <p class="card-text">Send important notifications to students and other faculty members.</p>
                        <a href="facNotification.php" class="btn btn-primary">Go to Send Notifications</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Upload Events</h5>
                        <p class="card-text">Upload upcoming events and schedules.</p>
                        <a href="facEventUpload.php" class="btn btn-primary">Go to View Events</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Logout</h5>
                        <p class="card-text">Logout from the faculty dashboard.</p>
                        <a href="Logout.php" class="btn btn-primary">Logout</a>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
</body>
</html>
