<?php
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecnotes";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['semester'])) {
    $semester = $_POST['semester'];
    $sql = "SELECT id, subject FROM subjects WHERE semester = '$semester'";
    $result = $conn->query($sql);
    echo '<option value="">Select Subject</option>';
    while ($row = $result->fetch_assoc()) {
        echo "<option value='".$row['subject']."'>".$row['subject']."</option>";
    }
}

$conn->close();
?>
