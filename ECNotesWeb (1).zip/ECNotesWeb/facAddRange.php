<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Range - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="index.php">EC Notes</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="facDashboard.php">Faculty Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Add Year Range</h2>
        <?php
        // Database connection details
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ecnotes";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Handle form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $yearrange = $_POST["yearrange"];

            // Prepare and bind
            $stmt = $conn->prepare("INSERT INTO syllabusyear (yearrange) VALUES (?)");
            $stmt->bind_param("s", $yearrange);

            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>New year range added successfully.</div>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
            }

            $stmt->close();
        }

        $conn->close();
        ?>

        <form action="facAddRange.php" method="post">
            <div class="form-group">
                <label for="yearrange">Year Range:</label>
                <input type="text" class="form-control" id="yearrange" name="yearrange" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Year Range</button>
        </form>
    </div>

</body>
</html>
