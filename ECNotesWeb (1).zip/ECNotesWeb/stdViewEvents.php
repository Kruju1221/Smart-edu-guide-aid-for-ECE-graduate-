<?php
// Database connection
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "ecnotes";

$conn = new mysqli($servername, $db_username, $db_password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all events
$events_sql = "SELECT * FROM events";
$events_result = $conn->query($events_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Events - EC Notes</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Student Dashboard</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="#navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="studentDashboard.php">Dashboard</a>  <!-- Link to Logout -->
                </li>
				<li class="nav-item">
                    <a class="nav-link" href="Logout.php">Logout</a>  <!-- Link to Logout -->
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h3>View Events</h3>

        <!-- Display the events in a table -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Event Name</th>
                    <th>Event Date</th>
                    <th>Description</th>
                    <th>Organizer</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($events_result->num_rows > 0) {
                    while ($row = $events_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['event_name'] . "</td>";
                        echo "<td>" . $row['event_date'] . "</td>";
                        echo "<td>" . $row['description'] . "</td>";
                        echo "<td>" . $row['organizer'] . "</td>";
                        echo "<td>" . $row['location'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No events found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <a href="studentDashboard.php" class="btn btn-primary">Back to Dashboard</a>
    </div>

</body>
</html>

<?php
$conn->close(); // Close the database connection
