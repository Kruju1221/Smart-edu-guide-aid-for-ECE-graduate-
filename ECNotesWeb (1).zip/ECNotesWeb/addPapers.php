<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root"; // Replace with your database username
$DB_PASS = ""; // Replace with your database password
$DB_NAME = "ecnotes"; // Replace with your database name

// Connect to the database
$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS, $DB_NAME) or die('Unable to Connect to Database');

// Handle POST data
$name = $_POST['name'];
$description = $_POST['description'];
$author = $_POST['author'];

// Validate the input fields
if (empty($name) || empty($description) || empty($author)) {
    $response['error'] = true;
    $response['message'] = "Please fill all required fields.";
    echo json_encode($response);
    exit();
}

// Insert data into the papers table
$insert_query = "INSERT INTO papers (name, description, author) 
                 VALUES ('$name', '$description', '$author')";

if (mysqli_query($db_con, $insert_query)) {
    $response['error'] = false;
    $response['message'] = "Paper added successfully";
    echo json_encode($response);
} else {
    $response['error'] = true;
    $response['message'] = "Unable to add paper: " . mysqli_error($db_con);
    echo json_encode($response);
}

// Close database connection
mysqli_close($db_con);
?>
